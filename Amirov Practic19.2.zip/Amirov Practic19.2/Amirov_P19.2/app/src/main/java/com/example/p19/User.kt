package com.example.p19
class User (var name: String, var age: Int) {
    override fun toString(): String {
        return "Имя: $name\nВозраст: $age"
    }
}